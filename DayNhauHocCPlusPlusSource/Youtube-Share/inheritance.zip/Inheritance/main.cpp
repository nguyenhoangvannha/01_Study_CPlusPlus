#include <iostream>
#include "ChaMe.h"
#include "ConCai.h"
using namespace std;
// Public/Protected/Private in C++
int main()
{
	ChaMe chame;
	chame.bienPublic = 1;
}